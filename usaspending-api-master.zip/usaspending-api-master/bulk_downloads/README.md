# Download Placeholder

Placeholder directory for local bulk downloads. Can safely be deleted if you are not using the /v2/download endpoint in development.