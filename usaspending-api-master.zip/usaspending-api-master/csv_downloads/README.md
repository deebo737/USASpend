# CSV Download Placeholder

Placeholder directory for local CSV downloads. Can safely be deleted if you are not using the /v2/download endpoint in development.
