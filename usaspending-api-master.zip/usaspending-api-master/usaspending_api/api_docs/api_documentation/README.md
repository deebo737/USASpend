# API Documentation

This folder has been replaced with a more up-to-date set of API Contracts that follow [API Blueprint](https://apiblueprint.org/) syntax.

The new API Contracts / documentation can be found by clicking [here](../../api_contracts/contracts/).