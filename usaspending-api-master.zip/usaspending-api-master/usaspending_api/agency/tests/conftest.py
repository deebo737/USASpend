from usaspending_api.agency.tests.fixtures.sub_agency_data import sub_agency_data_1

__all__ = [
    "sub_agency_data_1",
]
