from django.apps import AppConfig


class AccountsConfig(AppConfig):
    name = "usaspending_api.accounts"
