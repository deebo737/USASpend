from django.apps import AppConfig


class AwardsConfig(AppConfig):
    name = "usaspending_api.awards"
